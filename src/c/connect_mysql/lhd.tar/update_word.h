/*
 *  update_word.h
 *  connect_mysql
 *
 *  Created by Anders Bolt-Evensen on 4/8/10.
 *  Copyright 2010 Høgskolen i Østfold. All rights reserved.
 *
 */

int updateNorwegianWord();
int updateEnglishWord();