
class MatrixMultiplyIndex {

  /*
  * Rekursiv metode for matrisemultiplikasjon, implementert direkte etter 
  * pseudokoden i boka. Legg merke til at SubMatrix klassen brukes både til å
  * representere matriser og delmatriser.
  */
  public static SubMatrix multiply(SubMatrix a, SubMatrix b) {

    SubMatrix c = new SubMatrix(a.n);

    if (c.n == 1)
      c.set(0, 0, a.get(0, 0) * b.get(0, 0));
    else {

      SubMatrix[] aParts = a.partition();
      SubMatrix[] bParts = b.partition();
      SubMatrix[] cParts = c.partition();

      SubMatrix.add(
        multiply(aParts[0], bParts[0]),
        multiply(aParts[1], bParts[2]), 
        cParts[0]);
      SubMatrix.add(
        multiply(aParts[0], bParts[1]),
        multiply(aParts[1], bParts[3]), 
        cParts[1]);
      SubMatrix.add(
        multiply(aParts[2], bParts[0]),
        multiply(aParts[3], bParts[2]), 
        cParts[2]);
      SubMatrix.add(
        multiply(aParts[2], bParts[1]),
        multiply(aParts[3], bParts[3]), 
        cParts[3]);

    }
    
    return c;

  }

  public static void main(String[] args) {

    float[] m1 = {
      1f, 0f, 0f, 0f,
      0f, 1f, 0f, 0f,
      0f, 0f, 1f, 0f,
      0f, 0f, 0f, 1f };
    SubMatrix s1 = new SubMatrix(4, m1);
    float[] m2 = {
      1f, 2f, 3f, 4f,
      2f, 1f, 0f, 0f,
      3f, 0f, 1f, 0f,
      4f, 0f, 0f, 1f };
    SubMatrix s2 = new SubMatrix(4, m2);
    float[] m3 = {
      1f, 4f, 0f, 0f,
      0f, 0f, 3f, 6f,
      0f, 0f, 1f, -10f,
      2f, 0f, 5f, 1f };
    SubMatrix s3 = new SubMatrix(4, m3);
    float[] m4 = {
      1f, 2f, 3f, 4f,
      0f, 1f, 0f, 0f,
      0f, 0f, 1f, 0f,
      0f, 0f, 0f, 1f };
    SubMatrix s4 = new SubMatrix(4, m4);


    System.out.println(multiply(s2, s1));
    System.out.println(multiply(s3, s1));
    System.out.println(multiply(s2, s3));
    System.out.println(multiply(s4, s1));

    System.out.println(
      multiply(
        MatrixIO.readSubMatrix("m2.data"), 
        MatrixIO.readSubMatrix("m1.data")));

  }

}
