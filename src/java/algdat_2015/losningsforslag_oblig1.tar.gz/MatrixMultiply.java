
class MatrixMultiply {

  /*
  * Rekursiv multiplikasjonsmetode implementert direkte fra pseudokoden gitt i
  * forelesningen og fagboka.  
  */
  public static Matrix multiply(Matrix a, Matrix b) {

    int n = a.n;

    Matrix c = new Matrix(n);

    if (n == 1)
      c.set(0, 0, a.get(0, 0) * b.get(0, 0));
    else {
      
      Matrix[] aParts = a.partition();
      Matrix[] bParts = b.partition();
      Matrix[] cParts = c.partition();

      Matrix.add(
        multiply(aParts[0], bParts[0]),
        multiply(aParts[1], bParts[2]), 
        cParts[0]);
      Matrix.add(
        multiply(aParts[0], bParts[1]),
        multiply(aParts[1], bParts[3]), 
        cParts[1]);
      Matrix.add(
        multiply(aParts[2], bParts[0]),
        multiply(aParts[3], bParts[2]), 
        cParts[2]);
      Matrix.add(
        multiply(aParts[2], bParts[1]),
        multiply(aParts[3], bParts[3]), 
        cParts[3]);

      c.unPartition(cParts);

    }
    
    return c;

  }

  public static void main(String[] args) {

    System.out.println(
      multiply(
        MatrixIO.readMatrix(args[0]), 
        MatrixIO.readMatrix(args[1])));

  }

}
