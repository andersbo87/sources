#!/bin/sh
javacexists=`which javac`
if [ "$javacexists" != "" ]
then
    javac Dijkstra.java
else
    echo "Vennligst intaller JDK før du kjører dette skriptet."
    exit 1
fi
echo "Programmet skal nå kunne la seg kjøre."
echo "Syntaksen er: 'java Dijkstra fil1 arg1', der fil1 er filen som skal leses og arg1 er startnoden for søket."
