#!/bin/sh
# never assume bash to exist in /bin...

# Check if Java and javac is installed...
jpath=`which java`
jcpath=`which javac`

if [ $jpath == "" ]
then
    echo "Java could not be found in your PATH."
    exit 1
else
    if [ $jcpath == "" ]
    then
	echo "Javac could not be found in your PATH. Make sure that you've installed JDK (i.e. JDK 8), instead of only JRE."
	exit 1
    else
	echo "Trying to compile oppgave3_kopier.java (den med klassen Matrix)"
	$jcpath oppgave3_matrise.java
	echo "Trying to compile oppgave3_indeks.java (den med klassen SubMatrix)"
	$jcpath oppgave3_matrise.java
	echo "All done! "
    fi
fi
